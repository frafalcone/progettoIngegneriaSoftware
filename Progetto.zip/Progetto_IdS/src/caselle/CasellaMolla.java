package caselle;

import giocatore.Giocatore;

public class CasellaMolla extends CasellaPremio{

    protected CasellaMolla(int info, String tipo){
        super(info, tipo);
    }

    public String esegui(Giocatore giocatore) {
        giocatore.setTurnoFinito(false);
        giocatore.setMolla(true);
        return ("<br>Il "+ giocatore.toString() +" ha raggiunto una casella Molla ");
    }

}
