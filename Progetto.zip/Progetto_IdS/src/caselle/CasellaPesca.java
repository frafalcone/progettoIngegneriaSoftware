package caselle;

import giocatore.Giocatore;

public class CasellaPesca extends CasellaAb{

    private static Mazzo mazzo;
    private static boolean rDivieto;

    protected CasellaPesca(int info, String tipo){
        super(info, tipo);
        this.occupato = true;

        mazzo = Mazzo.getInstance();
        mazzo.setDivieto(rDivieto);
        mazzo.mischiaMazzo();
    }

    @Override
    public String esegui(Giocatore giocatore) {
            int carta = mazzo.pescaCarta();

            switch (carta){
                case 1 -> {
                    giocatore.attendiTurni(3);
                    return ("<br>Il "+ giocatore.toString() +" ha pescato una carta Locanda");
                }
                case 2 -> {
                    giocatore.setTurnoFinito(false);
                    giocatore.setLanciato(false);
                    return ("<br>Il "+ giocatore.toString() +" ha pescato una carta Dado");
                }
                case 3 -> {
                    giocatore.attendiTurni(1);
                    return ("<br>Il "+ giocatore.toString() +" ha pescato una carta Panchina");
                }
                case 4 -> {
                    giocatore.setTurnoFinito(false);
                    giocatore.setMolla(true);
                    return ("<br>Il "+ giocatore.toString() +" ha pescato una carta Molla");
                }
                case 5 -> {
                    giocatore.setDivieto(true);
                    return ("<br>Il "+ giocatore.toString() +" ha pescato una carta Divieto");
                }
            }

            return "";
    }

    public boolean getRDivieto() {return this.rDivieto;}

    public static void setRDivieto(boolean rD) {rDivieto = rD;}
}
