package caselle;

import giocatore.Giocatore;

public class CasellaLocanda extends CasellaSosta{

    protected CasellaLocanda(int info, String tipo){super(info, tipo); this.attesa = 3;}

    public String esegui(Giocatore giocatore) {
        giocatore.attendiTurni(this.attesa);
        return ("<br>Il "+giocatore.toString()+" deve attendere per "+ giocatore.getNumTurni() +" turni/o");
    }

}
