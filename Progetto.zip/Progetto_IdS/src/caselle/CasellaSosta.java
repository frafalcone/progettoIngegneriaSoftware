package caselle;

public abstract class CasellaSosta extends CasellaAb{
    int attesa;

    protected CasellaSosta(int info, String tipo){
        super(info, tipo);
        this.occupato = true;
    }

    private int getAttesa(){
        return attesa;
    }
}
