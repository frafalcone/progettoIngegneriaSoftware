package caselle;

import java.util.Random;

public class Mazzo {
    private static Mazzo instance = null;

    private boolean divieto;
    private int[] carte;

    private Mazzo(){
    }

    public void setDivieto(boolean divieto){
        this.divieto = divieto;
    }

    public static synchronized Mazzo getInstance(){
        if (instance==null) instance = new Mazzo();
        return instance;
    }

    public void mischiaMazzo(){
        if(!divieto) {
            this.carte = new int[12];
            Random rng = new Random();
            for (int i = 1; i <= 4; i++) {
                int c = 3;
                while (c > 0) {
                    int index = rng.nextInt(0,12);
                    if(carte[index]==0){
                        carte[index] = i;
                        c--;
                    }
                }
            }
        }
        if(divieto){
            this.carte = new int[15];
            Random rng = new Random();
            for (int i = 1; i <= 5; i++) {
                int c = 3;
                while (c > 0) {
                    int index = rng.nextInt(0,15);
                    if(carte[index]==0){
                        carte[index] = i;
                        c--;
                    }
                }
            }
        }
    }

    public int pescaCarta(){
        int carta = carte[0];
        for (int i = 0; i < carte.length-1; i++) {
            carte[i] = carte[i+1];
        }
        carte[carte.length-1] = carta;
        return carta;
    }
}
