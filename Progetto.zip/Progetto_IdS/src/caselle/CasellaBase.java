package caselle;

import giocatore.Giocatore;

public class CasellaBase extends CasellaAb{

    protected CasellaBase(int info, String tipo){
        super(info, tipo);
    }

    @Override
    public String esegui(Giocatore giocatore) {
        return "";
    }


}
