package caselle;

import giocatore.Giocatore;

public class CasellaScala extends CasellaAb{

    protected CasellaScala(int info, int destinazione, String tipo){
        super(info, tipo);
        this.destinazione = destinazione;
        this.occupato = true;
    }

    public String esegui(Giocatore giocatore) {
        giocatore.spostaPedina(destinazione-info);
        return ("<br>Il "+giocatore.toString()+ " ha raggiunto una scala spostandosi sulla casella ["+giocatore.getPosizione()+"]");

    }

}
