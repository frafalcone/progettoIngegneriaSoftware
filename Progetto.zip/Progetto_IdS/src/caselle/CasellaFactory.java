package caselle;

public interface CasellaFactory {
    Casella creaCasella(int info, int destinazione,String tipo);
}
