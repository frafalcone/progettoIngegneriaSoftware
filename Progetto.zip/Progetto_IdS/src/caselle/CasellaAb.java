package caselle;

public abstract class CasellaAb implements Casella{
    protected int info;
    protected int destinazione;
    protected boolean occupato;
    protected String tipo;

    protected CasellaAb(int info, String tipo){
        this.info = info;
        this.destinazione = -1;
        this.occupato = false;
        this.tipo = tipo;
    }

    public int getInfo() {return this.info;}

    @Override
    public void setInfo(int info) {this.info = info;}

    @Override
    public int getDestinazione() {return this.destinazione;}

    @Override
    public void setDestinazione(int destinazione) {this.destinazione = destinazione;}

    @Override
    public boolean getOccupato() {return this.occupato;}

    @Override
    public String getTipo(){return this.tipo;}

    @Override
    public void setOccupato(boolean occupato) {this.occupato = occupato;}

    public String toString(){
        String s = String.format("%14s[%03d]", this.tipo, this.info);
        return s;
    }
}
