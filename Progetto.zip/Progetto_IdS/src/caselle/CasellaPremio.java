package caselle;

public abstract class CasellaPremio extends CasellaAb{

    protected CasellaPremio(int info, String tipo){
        super(info, tipo);
        this.setOccupato(true);
    }

}
