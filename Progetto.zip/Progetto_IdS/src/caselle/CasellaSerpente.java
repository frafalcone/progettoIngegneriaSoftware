package caselle;

import giocatore.Giocatore;

public class CasellaSerpente extends CasellaAb{

    protected CasellaSerpente(int info, int destinazione, String tipo) {
        super(info, tipo);
        this.destinazione = destinazione;
        this.occupato = true;
    }

    @Override
    public String esegui(Giocatore giocatore) {
        giocatore.spostaPedina(-(info-destinazione));
        return ("<br>Il "+giocatore.toString()+ " ha raggiunto un serpente spostandosi sulla casella ["+giocatore.getPosizione()+"]");
    }

}

