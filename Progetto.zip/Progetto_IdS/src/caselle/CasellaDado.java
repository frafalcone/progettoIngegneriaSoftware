package caselle;

import giocatore.Giocatore;

public class CasellaDado extends CasellaPremio{

    protected CasellaDado(int info, String tipo){
        super(info, tipo);
    }

    public String esegui(Giocatore giocatore) {
        giocatore.setTurnoFinito(false);
        giocatore.setLanciato(false);
        return ("<br>Il "+ giocatore.toString() +" ha raggiunto una casella Dado ");
    }

}
