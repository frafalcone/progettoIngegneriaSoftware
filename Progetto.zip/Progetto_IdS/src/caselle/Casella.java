package caselle;

import giocatore.Giocatore;

public interface Casella{

    String esegui(Giocatore giocatore);

    int getInfo();
    void setInfo(int info);

    int getDestinazione();
    void setDestinazione(int info);

    boolean getOccupato();
    void setOccupato(boolean occupato);

    String getTipo();
}
