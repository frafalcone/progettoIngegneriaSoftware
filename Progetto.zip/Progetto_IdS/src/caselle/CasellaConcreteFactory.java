package caselle;

public class CasellaConcreteFactory implements CasellaFactory{

    @Override
    public Casella creaCasella(int info, int destinazione, String tipo) {
        Casella c;
        switch (tipo){
            case "Base"     -> c = new CasellaBase(info, tipo);
            case "Pesca"    -> c = new CasellaPesca(info, tipo);
            case "Locanda"  -> c = new CasellaLocanda(info, tipo);
            case "Panchina" -> c = new CasellaPanchina(info, tipo);
            case "Molla"    -> c = new CasellaMolla(info, tipo);
            case "Dado"     -> c = new CasellaDado(info, tipo);
            case "Scala"    -> c = new CasellaScala(info, destinazione, tipo);
            case "Serpente" -> c = new CasellaSerpente(info, destinazione, tipo);
            default         -> c = null;
        }
        return c;
    }
}
