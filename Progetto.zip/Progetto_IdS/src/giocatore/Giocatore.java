package giocatore;

import java.io.Serializable;
import java.util.Random;

public class Giocatore {

    private Random rng;

    private int dado, posizione, info, numTurni, ultimoLancio;

    private static boolean dadoSingolo, doppioSei, lancioSingolo;
    private boolean turnoFinito = false, divieto, lanciato, molla, ls_locale;

    public Giocatore(int info){
        this.rng = new Random();
        this.info = info;
        this.posizione = 1;
    }

    public int lancioDadi() {
        if(dadoSingolo || ls_locale){
            dado = rng.nextInt(6)+1;
        }
        else{
            dado = rng.nextInt(6)+1 + rng.nextInt(6)+1;
        }
        UltimoLancio(dado);
        return dado;
    }

    public String spostaPedina(int posizione) {
        this.posizione+=posizione;
       return ("<br>Il "+ toString()+ " si e' spostato sulla casella ["+ getPosizione() +"]");
    }

    public void attendiTurni(int turni) {
        this.numTurni = turni;
    }

    public int getNumTurni(){ return this.numTurni; }

    public int getPosizione() {
        return this.posizione;
    }

    public int getUltimoLancio(){ return this.ultimoLancio; }

    public boolean getTurnoFinito(){ return this.turnoFinito; }

    public boolean getDivieto() {
        return this.divieto;
    }

    public boolean getLanciato() {
        return this.lanciato;
    }

    public boolean getMolla() {
        return this.molla;
    }

    public boolean getDadoDoppio() { return doppioSei; }

    public boolean getDadoSingolo() { return dadoSingolo; }

    public boolean getLancioSingolo() { return lancioSingolo; }

    public void setLs_locale(boolean ls){ this.ls_locale = ls; }

    public void setDadoDoppio(boolean doppio){ doppioSei = doppio; }

    public void setDadoSingolo(boolean dS) { dadoSingolo = dS; }

    public void setLancioSingolo(boolean lS) { lancioSingolo = lS; }

    public void setMolla(boolean molla) {
        this.molla = molla;
    }

    public void setLanciato(boolean lanciato) {
        this.lanciato = lanciato;
    }

    public void setTurnoFinito(boolean turnoFinito){ this.turnoFinito = turnoFinito; }

    public void setDivieto(boolean divieto) {
        this.divieto = divieto;
    }

    private void UltimoLancio(int lancio){ this.ultimoLancio = lancio; }

    public String toString(){
        return "Giocatore " + this.info;
    }
}
