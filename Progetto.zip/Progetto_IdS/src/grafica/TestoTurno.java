package grafica;

import javax.swing.*;
import javax.swing.border.Border;
import java.awt.*;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;

public class TestoTurno extends Canvas{

    private static JFrame frame;
    private static String s;
    private static JLabel label;

    public TestoTurno(){
        frame = new JFrame("Turno Corrente");
        label = new JLabel();
    }

    public void stampa(String s) {

        this.s = s;
        label.setText(s);

        Border border = BorderFactory.createLineBorder(Color.BLACK);
        label.setBorder(border);
        label.setPreferredSize(new Dimension(400, 200));
        label.setHorizontalAlignment(SwingConstants.LEFT);
        label.setOpaque(true);
        frame.add(label);
        frame.pack();
        frame.setVisible(true);
        frame.revalidate();
        frame.repaint();



        frame.addWindowListener(new WindowAdapter() {
            @Override
            public void windowClosing(WindowEvent e) {
                System.exit(0);
            }
        });

    }

    public void paint(Graphics g){

    }
}
