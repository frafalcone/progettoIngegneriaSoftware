package grafica;

import caselle.Casella;
import giocatore.Giocatore;
import tabellone.Tabellone;

import javax.swing.*;
import java.awt.*;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.awt.font.FontRenderContext;
import java.awt.font.TextLayout;

public class TabelloneGraficoBase extends Canvas implements Grafica{

    private final JFrame frame;
    private Canvas canvas;
    private Tabellone t;
    private Giocatore[] giocatori;

    public TabelloneGraficoBase(Tabellone t, Giocatore[] g){
        this.t = t;
        this.giocatori = g;
        this.frame = new JFrame("Tabellone");

    }



    @Override
    public void disegna() {

        if(canvas == null){
            this.canvas = new TabelloneGraficoBase(t, giocatori);
            canvas.setSize(100 * t.getNumeroColonne(), 100*t.getNumeroRighe());

        }

        frame.add(canvas);
        frame.pack();
        frame.setVisible(true);
        frame.repaint();

        frame.addWindowListener(new WindowAdapter() {
            @Override
            public void windowClosing(WindowEvent e) {
                System.exit(0);
            }
        });
    }

    public void paint(Graphics g) {
        disegnaBase(g);
        disegnaSerpentiC(g);
        disegnaScaleC(g);
        disegnaPremio(g);
        disegnaSosta(g);
        disegnaPesca(g);
        disegnaSerpentiP(g);
        disegnaScaleP(g);
        disegnaNum(g);
        disegnaPedine(g);
    }

    public void disegnaBase(Graphics g){
        Graphics2D g2 = (Graphics2D) g;
        for(int i = 0; i<t.getNumeroRighe(); i++){
            for(int j = 0; j<t.getNumeroColonne(); j++){
                g2.setColor(Color.BLACK);
                g2.setStroke(new BasicStroke(10));
                g2.drawRect(100*j,100*i,100,100);
            }
        }
    }

    public void disegnaSerpentiC(Graphics g){
            int k = 1;
            Graphics2D g2 = (Graphics2D) g;
            for(int i = 0; i<t.getNumeroRighe(); i++){
                for(int j = 0; j<t.getNumeroColonne(); j++){
                    Casella c = Tabellone.getCasella(k);
                    if(c.getTipo().equals("Serpente")){
                        int x = t.getCoordinateX(k);
                        int y = t.getCoordinateY(k);
                        g2.setColor(Color.GREEN);
                        g2.fillRect((100*x)+5,(100*y)+5,90,90);
                    }
                    k++;
                }
            }
    }

    public void disegnaScaleC(Graphics g){
        int k = 1;
        Graphics2D g2 = (Graphics2D) g;
        for(int i = 0; i<t.getNumeroRighe(); i++){
            for(int j = 0; j<t.getNumeroColonne(); j++){
                Casella c = Tabellone.getCasella(k);
                if(c.getTipo().equals("Scala")){
                    int x = t.getCoordinateX(k);
                    int y = t.getCoordinateY(k);
                    g2.setColor(Color.LIGHT_GRAY);
                    g2.fillRect((100*x)+5,(100*y)+5,90,90);
                }
                k++;
            }
        }
    }

    public void disegnaSerpentiP(Graphics g){
        int k = 1;
        Graphics2D g2 = (Graphics2D) g;
        for(int i = 0; i<t.getNumeroRighe(); i++){
            for(int j = 0; j<t.getNumeroColonne(); j++){
                Casella c = Tabellone.getCasella(k);
                if(c.getTipo().equals("Serpente")){
                    int x = t.getCoordinateX(k);
                    int y = t.getCoordinateY(k);
                    int dest = c.getDestinazione();
                    int x2 = t.getCoordinateX(dest);
                    int y2 = t.getCoordinateY(dest);
                    g2.setStroke(new BasicStroke(15));
                    g2.setColor(Color.BLACK);
                    g2.drawLine((100*x)+50, (100*y)+50, (100*x2)+50, (100*y2)+50);
                    g2.setStroke(new BasicStroke(12));
                    g2.setColor(Color.GREEN);
                    g2.drawLine((100*x)+50, (100*y)+50, (100*x2)+50, (100*y2)+50);
                }
                k++;
            }
        }
    }

    public void disegnaScaleP(Graphics g){
        int k = 1;
        Graphics2D g2 = (Graphics2D) g;
        for(int i = 0; i<t.getNumeroRighe(); i++){
            for(int j = 0; j<t.getNumeroColonne(); j++){
                Casella c = Tabellone.getCasella(k);
                if(c.getTipo().equals("Scala")){
                    int x = t.getCoordinateX(k);
                    int y = t.getCoordinateY(k);
                    int dest = c.getDestinazione();
                    int x2 = t.getCoordinateX(dest);
                    int y2 = t.getCoordinateY(dest);
                    g2.setStroke(new BasicStroke(15));
                    g2.setColor(Color.BLACK);
                    g2.drawLine((100*x)+50, (100*y)+50, (100*x2)+50, (100*y2)+50);
                    g2.setStroke(new BasicStroke(12));
                    g2.setColor(Color.LIGHT_GRAY);
                    g2.drawLine((100*x)+50, (100*y)+50, (100*x2)+50, (100*y2)+50);
                }
                k++;
            }
        }
    }

    public void disegnaPremio(Graphics g){
        int k = 1;
        Graphics2D g2 = (Graphics2D) g;
        for(int i = 0; i<t.getNumeroRighe(); i++){
            for(int j = 0; j<t.getNumeroColonne(); j++){
                Casella c = Tabellone.getCasella(k);
                if(c.getTipo().equals("Dado")){
                    int x = t.getCoordinateX(k);
                    int y = t.getCoordinateY(k);
                    g2.setColor(Color.BLUE);
                    g2.fillRect((100*x)+5,(100*y)+5,90,90);
                }
                if(c.getTipo().equals("Molla")){
                    int x = t.getCoordinateX(k);
                    int y = t.getCoordinateY(k);
                    g2.setColor(Color.CYAN);
                    g2.fillRect((100*x)+5,(100*y)+5,90,90);
                }
                k++;
            }
        }
    }

    public void disegnaPesca(Graphics g){
        int k = 1;
        Graphics2D g2 = (Graphics2D) g;
        for(int i = 0; i<t.getNumeroRighe(); i++){
            for(int j = 0; j<t.getNumeroColonne(); j++){
                Casella c = Tabellone.getCasella(k);
                if(c.getTipo().equals("Pesca")){
                    int x = t.getCoordinateX(k);
                    int y = t.getCoordinateY(k);
                    g2.setColor(Color.RED);
                    g2.fillRect((100*x)+5,(100*y)+5,90,90);
                }
                k++;
            }
        }
    }

    public void disegnaSosta(Graphics g){
        int k = 1;
        Graphics2D g2 = (Graphics2D) g;
        for(int i = 0; i<t.getNumeroRighe(); i++){
            for(int j = 0; j<t.getNumeroColonne(); j++){
                Casella c = Tabellone.getCasella(k);
                if(c.getTipo().equals("Locanda")){
                    int x = t.getCoordinateX(k);
                    int y = t.getCoordinateY(k);
                    g2.setColor(Color.PINK);
                    g2.fillRect((100*x)+5,(100*y)+5,90,90);
                }
                if(c.getTipo().equals("Panchina")){
                    int x = t.getCoordinateX(k);
                    int y = t.getCoordinateY(k);
                    g2.setColor(Color.MAGENTA);
                    g2.fillRect((100*x)+5,(100*y)+5,90,90);
                }
                k++;
            }
        }
    }

    public void disegnaPedine(Graphics g){
        Graphics2D g2 = (Graphics2D) g;
        for (int i=0; i<giocatori.length; i++){
            int pos = giocatori[i].getPosizione();
            int x = t.getCoordinateX(pos);
            int y = t.getCoordinateY(pos);
            g2.setColor(Color.BLACK);
            switch(i){
                case 0 ->g2.fillOval((100*x)+10,(100*y)+10,30,30);
                case 1 ->g2.fillOval((100*x)+60,(100*y)+10,30,30);
                case 2 ->g2.fillOval((100*x)+35,(100*y)+35,30,30);
                case 3 ->g2.fillOval((100*x)+10,(100*y)+60,30,30);
                case 4 ->g2.fillOval((100*x)+60,(100*y)+60,30,30);
                default -> {}
            }
        }
    }

    public void disegnaNum(Graphics g){
        int k = t.getNumeroColonne()*t.getNumeroRighe();
        Graphics2D g2 = (Graphics2D) g;
        for(int i = 0; i<t.getNumeroRighe(); i++){
            if(i%2==0)
                for(int j=0; j<t.getNumeroColonne(); j++){
                    Casella c = Tabellone.getCasella(k);
                    FontRenderContext frc = g2.getFontRenderContext();
                    Font font1 = new Font("Arial", Font.BOLD, 18);
                    Integer info = c.getInfo();
                    TextLayout tl = new TextLayout(info.toString(), font1, frc);
                    g2.setColor(Color.BLACK);
                    tl.draw(g2, (100*j)+40,(100*i)+50);
                    k--;
                }
            if(i%2!=0)
                for(int j=t.getNumeroColonne()-1; j>=0; j--){
                    Casella c = Tabellone.getCasella(k);
                    FontRenderContext frc = g2.getFontRenderContext();
                    Font font1 = new Font("Arial", Font.BOLD, 18);
                    Integer info = c.getInfo();
                    TextLayout tl = new TextLayout(info.toString(), font1, frc);
                    g2.setColor(Color.BLACK);
                    tl.draw(g2, (100*j)+40,(100*i)+50);
                    k--;
                }
        }
    }

}
