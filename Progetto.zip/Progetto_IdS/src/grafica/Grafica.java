package grafica;

public interface Grafica {
    void disegna();
}
