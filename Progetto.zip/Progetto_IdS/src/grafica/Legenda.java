package grafica;

import javax.swing.*;
import java.awt.*;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.awt.font.FontRenderContext;
import java.awt.font.TextLayout;

public class Legenda extends Canvas implements Grafica {

    private final JFrame frame;
    private Canvas canvas;

    public Legenda(){
        frame = new JFrame("Legenda");
    }

    @Override
    public void disegna() {
        canvas = new Legenda();
        canvas.setSize(400 , 400);
        frame.add(canvas);
        frame.pack();
        frame.setVisible(true);

        frame.addWindowListener(new WindowAdapter() {
            @Override
            public void windowClosing(WindowEvent e) {
                System.exit(0);
            }
        });
    }

    public void paint(Graphics g) {
        legendaBase(g);
        legendaSerpenti(g);
        legendaScale(g);
        legendaDado(g);
        legendaMolla(g);
        legendaPanchina(g);
        legendaLocanda(g);
        legendaPesca(g);
        legendaPedina(g);
    }

    private void legendaBase(Graphics g){
        Graphics2D g2 = (Graphics2D) g;
        FontRenderContext frc = g2.getFontRenderContext();
        Font font1 = new Font("Arial", Font.BOLD, 12);
        String str1 = ("Casella Base");
        TextLayout tl = new TextLayout(str1, font1, frc);
        g2.setColor(Color.BLACK);
        tl.draw(g2, 20, 20);
        g2.setColor(Color.BLACK);
        g2.setStroke(new BasicStroke(5));
        g2.drawRect(30,30,50,50);
    }

    private void legendaSerpenti(Graphics g){
        Graphics2D g2 = (Graphics2D) g;
        FontRenderContext frc = g2.getFontRenderContext();
        Font font1 = new Font("Arial", Font.BOLD, 12);
        String str1 = ("Casella Serpenti");
        TextLayout tl = new TextLayout(str1, font1, frc);
        g2.setColor(Color.BLACK);
        tl.draw(g2, 140, 20);
        g2.setColor(Color.BLACK);
        g2.setStroke(new BasicStroke(5));
        g2.drawRect(150,30,50,50);
        g2.setColor(Color.GREEN);
        g2.setStroke(new BasicStroke(0));
        g2.fillRect(153,33,45,45);
    }

    private void legendaScale(Graphics g){
        Graphics2D g2 = (Graphics2D) g;
        FontRenderContext frc = g2.getFontRenderContext();
        Font font1 = new Font("Arial", Font.BOLD, 12);
        String str1 = ("Casella Scale");
        TextLayout tl = new TextLayout(str1, font1, frc);
        g2.setColor(Color.BLACK);
        tl.draw(g2, 260, 20);
        g2.setColor(Color.BLACK);
        g2.setStroke(new BasicStroke(5));
        g2.drawRect(270,30,50,50);
        g2.setColor(Color.GRAY);
        g2.setStroke(new BasicStroke(0));
        g2.fillRect(273,33,45,45);
    }

    private void legendaPesca(Graphics g){
        Graphics2D g2 = (Graphics2D) g;
        FontRenderContext frc = g2.getFontRenderContext();
        Font font1 = new Font("Arial", Font.BOLD, 12);
        String str1 = ("Casella Pesca");
        TextLayout tl = new TextLayout(str1, font1, frc);
        g2.setColor(Color.BLACK);
        tl.draw(g2, 20, 150);
        g2.setColor(Color.BLACK);
        g2.setStroke(new BasicStroke(5));
        g2.drawRect(30,160,50,50);
        g2.setColor(Color.RED);
        g2.setStroke(new BasicStroke(0));
        g2.fillRect(33,163,45,45);
    }

    private void legendaDado(Graphics g){
        Graphics2D g2 = (Graphics2D) g;
        FontRenderContext frc = g2.getFontRenderContext();
        Font font1 = new Font("Arial", Font.BOLD, 12);
        String str1 = ("Casella Dado");
        TextLayout tl = new TextLayout(str1, font1, frc);
        g2.setColor(Color.BLACK);
        tl.draw(g2, 140, 150);
        g2.setColor(Color.BLACK);
        g2.setStroke(new BasicStroke(5));
        g2.drawRect(150,160,50,50);
        g2.setColor(Color.BLUE);
        g2.setStroke(new BasicStroke(0));
        g2.fillRect(153,163,45,45);
    }

    private void legendaMolla(Graphics g){
        Graphics2D g2 = (Graphics2D) g;
        FontRenderContext frc = g2.getFontRenderContext();
        Font font1 = new Font("Arial", Font.BOLD, 12);
        String str1 = ("Casella Molla");
        TextLayout tl = new TextLayout(str1, font1, frc);
        g2.setColor(Color.BLACK);
        tl.draw(g2, 260, 150);
        g2.setColor(Color.BLACK);
        g2.setStroke(new BasicStroke(5));
        g2.drawRect(270,160,50,50);
        g2.setColor(Color.CYAN);
        g2.setStroke(new BasicStroke(0));
        g2.fillRect(273,163,45,45);
    }

    private void legendaPanchina(Graphics g){
        Graphics2D g2 = (Graphics2D) g;
        FontRenderContext frc = g2.getFontRenderContext();
        Font font1 = new Font("Arial", Font.BOLD, 12);
        String str1 = ("Casella Panchina");
        TextLayout tl = new TextLayout(str1, font1, frc);
        g2.setColor(Color.BLACK);
        tl.draw(g2, 20, 300);
        g2.setColor(Color.BLACK);
        g2.setStroke(new BasicStroke(5));
        g2.drawRect(30,310,50,50);
        g2.setColor(Color.MAGENTA);
        g2.setStroke(new BasicStroke(0));
        g2.fillRect(33,313,45,45);
    }

    private void legendaLocanda(Graphics g){
        Graphics2D g2 = (Graphics2D) g;
        FontRenderContext frc = g2.getFontRenderContext();
        Font font1 = new Font("Arial", Font.BOLD, 12);
        String str1 = ("Casella Locanda");
        TextLayout tl = new TextLayout(str1, font1, frc);
        g2.setColor(Color.BLACK);
        tl.draw(g2, 140, 300);
        g2.setColor(Color.BLACK);
        g2.setStroke(new BasicStroke(5));
        g2.drawRect(150,310,50,50);
        g2.setColor(Color.PINK);
        g2.setStroke(new BasicStroke(0));
        g2.fillRect(153,313,45,45);
    }

    private void legendaPedina(Graphics g){
        Graphics2D g2 = (Graphics2D) g;
        FontRenderContext frc = g2.getFontRenderContext();
        Font font1 = new Font("Arial", Font.BOLD, 12);
        String str1 = ("Pedina");
        TextLayout tl = new TextLayout(str1, font1, frc);
        g2.setColor(Color.BLACK);
        tl.draw(g2, 275, 300);
        g2.setColor(Color.BLACK);
        g2.setStroke(new BasicStroke(5));
        g2.fillOval(270,310,50,50);
    }


}
