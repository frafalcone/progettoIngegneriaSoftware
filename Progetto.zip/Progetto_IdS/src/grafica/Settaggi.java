package grafica;

import sistema.Sistema;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class Settaggi implements Grafica, ItemListener, ActionListener {

    private final JFrame frame;
    private final JCheckBox DS, DD, LS, CS, CP, CC, UC;
    private final JButton Avvia, Piccolo, Medio, Grande, piu_ng, meno_ng, piu_tr, meno_tr, piu_tc, meno_tc, Carica, Salva;
    private final JTextField tng, ttr, ttc, vuoto;
    private Sistema s = new Sistema();

    private static int numGiocatori=2, numColonne=6, numRighe=6;
    private static boolean primaCreazione = false, nuovo=false;

    public Settaggi(){

        this.frame = new JFrame("Settaggi Partita");
        frame.setLayout(new GridLayout(8,3));

        ttr=new JTextField("Righe: "+numRighe);
        ttr.setHorizontalAlignment(SwingConstants.CENTER);
        ttc=new JTextField("Colonne: "+numColonne);
        ttc.setHorizontalAlignment(SwingConstants.CENTER);
        tng=new JTextField("Giocatori: "+numGiocatori);
        tng.setHorizontalAlignment(SwingConstants.CENTER);
        vuoto = new JTextField();


        Carica = new JButton("Carica");
        Salva = new JButton("Salva");
        piu_ng = new JButton("+");
        meno_ng = new JButton("-");
        piu_tr = new JButton("+");
        meno_tr = new JButton("-");
        piu_tc = new JButton("+");
        meno_tc = new JButton("-");
        Piccolo = new JButton("Piccolo");
        Medio = new JButton("Medio");
        Grande = new JButton("Grande");
        DS = new JCheckBox("Dado Singolo");
        DD = new JCheckBox("Doppio Sei");
        LS = new JCheckBox("Lancio Singolo");
        CS = new JCheckBox("Caselle Sosta");
        CP = new JCheckBox("Caselle Premio");
        CC = new JCheckBox("Caselle Pesca");
        UC = new JCheckBox("Ulteriori Carte");
        Avvia = new JButton("Avvia");

        UC.setEnabled(false);
        tng.setEditable(false);
        ttc.setEditable(false);
        ttr.setEditable(false);
        vuoto.setEditable(false);
        meno_ng.setEnabled(false);
        meno_tr.setEnabled(false);
        meno_tc.setEnabled(false);

    }

    @Override
    public void disegna() {
        DS.addItemListener(this);
        DD.addItemListener(this);
        LS.addItemListener(this);
        CS.addItemListener(this);
        CC.addItemListener(this);
        CP.addItemListener(this);
        UC.addItemListener(this);
        piu_ng.addActionListener(this);
        meno_ng.addActionListener(this);
        piu_tr.addActionListener(this);
        meno_tr.addActionListener(this);
        piu_tc.addActionListener(this);
        meno_tc.addActionListener(this);
        Avvia.addActionListener(this);
        Piccolo.addActionListener(this);
        Medio.addActionListener(this);
        Grande.addActionListener(this);
        Carica.addActionListener(this);
        Salva.addActionListener(this);


        piu_ng.setActionCommand("piu_ng");
        meno_ng.setActionCommand("meno_ng");
        piu_tr.setActionCommand("piu_tr");
        meno_tr.setActionCommand("meno_tr");
        piu_tc.setActionCommand("piu_tc");
        meno_tc.setActionCommand("meno_tc");
        Piccolo.setActionCommand("Piccolo");
        Medio.setActionCommand("Medio");
        Grande.setActionCommand("Grande");
        Avvia.setActionCommand("Avvia");
        Carica.setActionCommand("Carica");
        Salva.setActionCommand("Salva");
        Carica.setActionCommand("Carica");


        frame.add(meno_ng);
        frame.add(tng);
        frame.add(piu_ng);
        frame.add(meno_tr);
        frame.add(ttr);
        frame.add(piu_tr);
        frame.add(meno_tc);
        frame.add(ttc);
        frame.add(piu_tc);
        frame.add(Piccolo);
        frame.add(Medio);
        frame.add(Grande);
        frame.add(DS);
        frame.add(DD);
        frame.add(LS);
        frame.add(CS);
        frame.add(CP);
        frame.add(CC);
        frame.add(UC);
        frame.add(Salva);
        frame.add(Carica);
        frame.add(vuoto);
        frame.add(Avvia);


        frame.pack();
        frame.setVisible(true);
        frame.repaint();



        frame.addWindowListener(new WindowAdapter() {
            @Override
            public void windowClosing(WindowEvent e) {
                if(!primaCreazione)
                    System.exit(0);
            }
        });

    }

    @Override
    public void itemStateChanged(ItemEvent e) {
        if(DS.isSelected()){
            s.setDadoSingolo(true);
            DD.setEnabled(false);
            LS.setEnabled(false);
        }
        else {
            s.setDadoSingolo(false);
            DD.setEnabled(true);
            LS.setEnabled(true);
        }

        if(DD.isSelected() || LS.isSelected()){
            DS.setEnabled(false);
        }
        else {
            DS.setEnabled(true);
        }

        if(DD.isSelected()){
            s.setDadoDoppio(true);
        }
        else {
            s.setDadoDoppio(false);
        }

        if(LS.isSelected()){
            s.setLancioSingolo(true);
        }
        else {
            s.setLancioSingolo(false);
        }

        if(CC.isSelected()){
            s.setCasellePesca(true);
            UC.setEnabled(true);
        }
        else {
            s.setCasellePesca(false);
            s.setUlterioriCarte(false);
            UC.setSelected(false);
            UC.setEnabled(false);
        }

        if(CS.isSelected()){
            s.setCaselleSosta(true);
        }
        else {
            s.setCaselleSosta(false);
        }

        if(CP.isSelected()){
            s.setCasellePremio(true);
        }
        else {
            s.setCasellePremio(false);
        }

        if(UC.isSelected()){
            s.setUlterioriCarte(true);
        }
        else {
            s.setUlterioriCarte(false);
        }
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if ("piu_ng".equals(e.getActionCommand())) {
            numGiocatori += 1;
            tng.setText("Giocatori: "+numGiocatori);
            s.setNumGiocatori(numGiocatori);
            if(numGiocatori>=5){
                piu_ng.setEnabled(false);
            }
            if(numGiocatori>2){
                meno_ng.setEnabled(true);
            }
        }
        if ("meno_ng".equals(e.getActionCommand())) {
            numGiocatori -= 1;
            tng.setText("Giocatori: "+numGiocatori);
            s.setNumGiocatori(numGiocatori);
            if(numGiocatori<=2){
                meno_ng.setEnabled(false);
            }
            if(numGiocatori<5){
                piu_ng.setEnabled(true);
            }
        }
        if ("piu_tr".equals(e.getActionCommand())) {
            numRighe += 1;
            ttr.setText("Righe: "+numRighe);
            s.setNumGiocatori(numGiocatori);
            if(numRighe>=10){
                piu_tr.setEnabled(false);
            }
            if(numRighe>6){
                meno_tr.setEnabled(true);
            }
        }
        if ("meno_tr".equals(e.getActionCommand())) {
            numRighe -= 1;
            ttr.setText("Righe: "+numRighe);
            s.setDimensioneTabellone(numRighe,numColonne);
            if(numRighe<=6){
                meno_tr.setEnabled(false);
            }
            if(numRighe<10){
                piu_tr.setEnabled(true);
            }
        }
        if ("piu_tc".equals(e.getActionCommand())) {
            numColonne += 1;
            ttc.setText("Colonne: "+numColonne);
            s.setDimensioneTabellone(numRighe,numColonne);
            if(numColonne>=10){
                piu_tc.setEnabled(false);
            }
            if(numColonne>6){
                meno_tc.setEnabled(true);
            }
        }
        if ("meno_tc".equals(e.getActionCommand())) {
            numColonne -= 1;
            ttc.setText("Colonne: "+numColonne);
            s.setDimensioneTabellone(numRighe,numColonne);
            if(numColonne<=6){
                meno_tc.setEnabled(false);
            }
            if(numColonne<10){
                piu_tc.setEnabled(true);
            }
        }
        if ("Piccolo".equals(e.getActionCommand())) {
            numRighe=6;
            numColonne=6;
            piu_tc.setEnabled(true);
            piu_tr.setEnabled(true);
            meno_tc.setEnabled(false);
            meno_tr.setEnabled(false);
            ttc.setText("Colonne: "+numColonne);
            ttr.setText("Righe: "+numRighe);
            s.setDimensioneTabellone(numRighe,numColonne);
        }
        if ("Medio".equals(e.getActionCommand())) {
            numRighe=8;
            numColonne=8;
            piu_tc.setEnabled(true);
            piu_tr.setEnabled(true);
            meno_tc.setEnabled(true);
            meno_tr.setEnabled(true);
            ttc.setText("Colonne: "+numColonne);
            ttr.setText("Righe: "+numRighe);
            s.setDimensioneTabellone(numRighe,numColonne);
        }
        if ("Grande".equals(e.getActionCommand())) {
            numRighe=10;
            numColonne=10;
            piu_tc.setEnabled(false);
            piu_tr.setEnabled(false);
            meno_tc.setEnabled(true);
            meno_tr.setEnabled(true);
            ttc.setText("Colonne: "+numColonne);
            ttr.setText("Righe: "+numRighe);
            s.setDimensioneTabellone(numRighe,numColonne);
        }
        if ("Avvia".equals(e.getActionCommand())) {
            s.setPartitaCreata(true);
            primaCreazione = true;
            frame.dispatchEvent(new WindowEvent(frame, WindowEvent.WINDOW_CLOSING));
        }

        if("Carica".equals(e.getActionCommand())){
            Sistema.caricaFile();
            primaCreazione = true;
            if(s.getPartitaCaricata())
                frame.dispatchEvent(new WindowEvent(frame, WindowEvent.WINDOW_CLOSING));
        }

        if("Salva".equals(e.getActionCommand())){
            Sistema.salvaFile();
        }
    }
}
