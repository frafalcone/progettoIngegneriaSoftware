package grafica;

import sistema.Sistema;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;


public class TurnoSuccessivo implements Grafica, ActionListener{

    private final JFrame frame;
    private final JButton mButton, aButton, pButton;
    private Sistema s = new Sistema();

    public TurnoSuccessivo(){
        this.frame = new JFrame("Comandi");
        mButton = new JButton("manuale");
        aButton = new JButton("automatico");
        pButton = new JButton("prossimo");
    }

    @Override
    public void disegna() {

        aButton.setActionCommand("automatico");
        mButton.setActionCommand("manuale");
        pButton.setActionCommand("prossimo");

        aButton.addActionListener(this);
        mButton.addActionListener(this);
        pButton.addActionListener(this);

        frame.setLayout(new GridLayout(1,3));
        frame.add(aButton);
        frame.add(mButton);
        frame.add(pButton);

        frame.pack();
        frame.setVisible(true);
        frame.repaint();

        frame.addWindowListener(new WindowAdapter() {
            @Override
            public void windowClosing(WindowEvent e) {
                System.exit(0);
            }
        });
    }


    @Override
    public void actionPerformed(ActionEvent e){
        if ("manuale".equals(e.getActionCommand())) {
            s.setManuale(true);
            pButton.setEnabled(true);
        }
        if ("prossimo".equals(e.getActionCommand())) {
            s.setProssimo(true);
        }
        if ("automatico".equals(e.getActionCommand())) {
            s.setManuale(false);
            pButton.setEnabled(false);
        }
    }
}
