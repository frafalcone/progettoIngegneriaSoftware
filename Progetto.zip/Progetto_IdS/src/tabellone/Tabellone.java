package tabellone;

import caselle.Casella;
import caselle.CasellaConcreteFactory;
import caselle.CasellaFactory;

import java.io.Serializable;
import java.util.Random;

public class Tabellone{
    private Random rng;
    private int numeroCaselle;
    private int numeroRighe;
    private int numeroColonne;
    public static Casella[][] tabellone;
    private static Tabellone instance = null;

    private Tabellone(int n, int m){
        this.numeroRighe = n;
        this.numeroColonne = m;
        this.numeroCaselle = n*m;
        CasellaFactory CF = new CasellaConcreteFactory();
        tabellone = new Casella[n][m];
        int k=n*m;
        for(int i = 0; i<n; i++){
            if(i%2==0)
                for(int j=0; j<m; j++){
                    tabellone[i][j] = CF.creaCasella(k, -1, "Base");
                    k--;
                }
            if(i%2!=0)
                for(int j=m-1; j>=0; j--){
                    tabellone[i][j] = CF.creaCasella(k, -1, "Base");
                    k--;
                }
        }
    }

    public static synchronized Tabellone getInstance(int n, int m){
        if(instance == null) instance = new Tabellone(n,m);
        return instance;
    }

    public void posizioneSerpenti(int i){
        Casella cs = null;
        Casella cd = null;
        int cont = i;
        this.rng = new Random();
        CasellaFactory CF = new CasellaConcreteFactory();
        while(cont>0){
            int info = rng.nextInt(tabellone[0].length+1, numeroCaselle);
            cs = getCasella(info);
            if (cs!=null &&!cs.getOccupato()){
                int dest = rng.nextInt(0,   info - (info % tabellone[0].length))+1;
                cd = getCasella(dest);
                    if (cd!=null && !cd.getOccupato()) {
                        cs = CF.creaCasella(info, dest, "Serpente");
                        setCasella(info, cs);
                        cd.setOccupato(true);
                        setCasella(dest, cd);
                        cont--;
                    }
            }
        }
    }

    public void posizionaScale(int i){
        Casella cs = null;
        Casella cd = null;
        int cont = i;
        this.rng = new Random();
        CasellaFactory CF = new CasellaConcreteFactory();
        while(cont>0){
            int info = rng.nextInt(2, numeroCaselle-tabellone[0].length);
            cs = getCasella(info);
            if (cs!=null && !cs.getOccupato()){
                int dest = rng.nextInt(info + (tabellone[0].length - (info % tabellone[0].length)), numeroCaselle) + 1;
                cd = getCasella(dest);
                if (cd != null && !cd.getOccupato()) {
                    cs = CF.creaCasella(info, dest, "Scala");
                    setCasella(info, cs);
                    cd.setOccupato(true);
                    setCasella(dest, cd);
                    cont--;
                }
            }
        }
    }

    public void posizionaSpeciali(int i, String tipo){
        Casella cs = null;
        int cont = i;
        this.rng = new Random();
        CasellaFactory CF = new CasellaConcreteFactory();
        while(cont>0){
            int info = rng.nextInt(2, numeroCaselle);
            cs = getCasella(info);
            if(cs != null && !cs.getOccupato()){
                int scelta;
                switch (tipo){
                    case "Premio": {
                        scelta = rng.nextInt(1, 3);
                        if(scelta == 1)
                            cs = CF.creaCasella(info, -1, "Molla");
                        if(scelta == 2)
                            cs = CF.creaCasella(info, -1, "Dado");
                        setCasella(info, cs);
                        cont--;
                        break;
                    }

                    case "Sosta": {
                        scelta = rng.nextInt(1, 3);
                        if(scelta == 1)
                            cs = CF.creaCasella(info, -1, "Panchina");
                        if(scelta == 2)
                            cs = CF.creaCasella(info, -1, "Locanda");
                        setCasella(info, cs);
                        cont--;
                        break;
                    }

                    case "Pesca": {
                        cs = CF.creaCasella(info, -1, "Pesca");
                        setCasella(info, cs);
                        cont--;
                        break;
                    }

                    default: {
                        cs = null;
                        break;
                    }
                }

            }
        }
    }

    public static Casella getCasella(int info){
        Casella c = null;
        for(int i = 0; i<tabellone.length; i++) {
            for (int j = 0; j < tabellone[i].length; j++) {
                if(tabellone[i][j].getInfo() == info)
                    c = tabellone[i][j];
            }
        }
        return c;
    }

    public void setCasella(int info, Casella c){
        for(int i = 0; i<tabellone.length; i++) {
            for (int j = 0; j < tabellone[i].length; j++) {
                if(tabellone[i][j].getInfo() == info)
                    tabellone[i][j] = c;
            }
        }
    }

    public static void stampa(){
        for(int i = 0; i<tabellone.length; i++) {
            for (int j = 0; j < tabellone[i].length; j++) {
                System.out.format(tabellone[i][j].toString());
            }
            System.out.println();
        }
    }

    public int getCoordinateY(int info){
        for(int i = 0; i<tabellone.length; i++) {
            for (int j = 0; j < tabellone[i].length; j++) {
                if(tabellone[i][j].getInfo() == info){
                    return i;
                }
            }
        }
        return -1;
    }

    public int getCoordinateX(int info){
        for(int i = 0; i<tabellone.length; i++) {
            for (int j = 0; j < tabellone[i].length; j++) {
                if(tabellone[i][j].getInfo() == info){
                    return j;
                }
            }
        }
        return -1;
    }

    public int getNumeroRighe() {
        return numeroRighe;
    }

    public int getNumeroColonne(){
        return numeroColonne;
    }
}
