package sistema;

import caselle.CasellaPesca;
import grafica.*;
import caselle.Casella;
import giocatore.Giocatore;
import tabellone.Tabellone;


import javax.swing.*;
import javax.swing.filechooser.FileSystemView;
import java.io.*;
import java.util.concurrent.TimeUnit;

public class Sistema implements Serializable{

    private static final long serialVersionUID = -6158493740264371995L;

    private static int n, m;

    private static Giocatore g0 = new Giocatore(0);
    private static int numGiocatori;
    private static Giocatore[] giocatori;

    private static boolean manuale = true;
    private static boolean prossimoTurno = false;
    private static boolean partitaCreata = false;
    private static boolean caselleSosta = false;
    private static boolean casellePremio = false;
    private static boolean casellePesca = false;
    private static boolean partitaCaricata = false;
    private static boolean finito = false;


    private int local_n, local_m, local_numG;
    private boolean local_manuale, local_caselleSosta, local_casellePremio, local_casellePesca;


    public static void main(String[] args) throws InterruptedException {

        Grafica st = new Settaggi();

        n=6;
        m=6;
        numGiocatori=2;
        System.out.println(n);

        int ds = 0;
        while(!partitaCreata){
            if(ds==0){
                st.disegna();
                ds++;
            }
            System.out.println("");
        }

        creaPartita();

        Tabellone t = Tabellone.getInstance(n,m);

        TestoTurno tt = new TestoTurno();
        Grafica tg = new TabelloneGraficoBase(t, giocatori);

        int i = -1;
        int k = 0;

        tg.disegna();
        while (!finito) {
            if (i == k) {
                if (!manuale)
                    TimeUnit.SECONDS.sleep(2);
                tt.stampa(turno(giocatori[i]));
                tg.disegna();
                k++;
                if (k == numGiocatori)
                    k = 0;
            }

            if (!manuale) {
                i++;
                if (i == numGiocatori)
                    i = 0;
            }

            if (manuale) {
                if (prossimoTurno) {
                    i++;
                    if (i == numGiocatori)
                        i = 0;
                    prossimoTurno = false;
                }
            }
            System.out.println("");
        }
    }

    public static void creaPartita(){

        double tmp = 0.10*(n*m);
        int numeroCaselleSpeciali = (int) tmp;

        tmp = 0.06*(n*m);
        int numeroScaleSerpenti = (int) tmp;

        giocatori = new Giocatore[numGiocatori];

        for (int i = 0; i< giocatori.length; i++){
            giocatori[i] = new Giocatore(i+1);
        }
        
        
        Tabellone t = Tabellone.getInstance(n,m);
        
        Grafica ts = new TurnoSuccessivo();
        Grafica lg = new Legenda();

        t.posizioneSerpenti(numeroScaleSerpenti);
        t.posizionaScale(numeroScaleSerpenti);



        if(caselleSosta)
            t.posizionaSpeciali(numeroCaselleSpeciali, "Sosta");
        if(casellePremio)
            t.posizionaSpeciali(numeroCaselleSpeciali, "Premio");
        if(casellePesca){
            t.posizionaSpeciali(numeroCaselleSpeciali, "Pesca");
        }

        ts.disegna();
        lg.disegna();

        
    }

    public static String turno(Giocatore g){
        boolean divietoUsato=false;

        String s = "";

        if(g.getNumTurni()!=0 && g.getDivieto() ) {
            g.attendiTurni(0);
            s+=("<html>Il " + g.toString() + " ha usato la carta Divieto");
            divietoUsato = true;
            g.setDivieto(false);
        }

        if( (g.getNumTurni()==0 || g.getDivieto() ) && g.getPosizione() != n*m ){
            if(divietoUsato)
                s+=("<br><br>Turno del "+ g.toString()+"<br>");
            if(!divietoUsato)
                s+=("<html>Turno del "+ g.toString()+"<br>");
            g.setTurnoFinito(false);
            g.setLanciato(false);

            while(!g.getTurnoFinito()){

                if (g.getLancioSingolo() && g.getPosizione() >= n*m - 6){
                    g.setLs_locale(true);
                }
                else {
                    g.setLs_locale(false);
                }

                if(!g.getLanciato() || g.getMolla()){
                    int dado = 0;

                    if(!g.getLanciato()){
                        dado = g.lancioDadi();
                        s+=("<br>Il "+ g.toString() +" ha lanciato i dadi ottenendo ["+ dado +"]");
                        g.setLanciato(true);
                    }

                    if(g.getMolla()){
                        dado = g.getUltimoLancio();
                        g.setMolla(false);
                    }

                    if(g.getPosizione()+dado > n*m){
                        dado = (n*m - g.getPosizione()) - (dado - (n*m - g.getPosizione()));
                    }
                    s+=g.spostaPedina(dado);

                }

                g.setTurnoFinito(true);
                Casella c = Tabellone.getCasella(g.getPosizione());
                s+=c.esegui(g);

                if(g.getUltimoLancio() == 12 && (g.getNumTurni() == 0 || g.getDivieto()) && g.getDadoDoppio()){

                    if(g.getDivieto()) {
                        g.setDivieto(false);
                        s+=("<br>Il " + g.toString() + " ha usato la carta Divieto");
                        g.attendiTurni(0);
                    }

                    g.setLanciato(false);
                    g.setTurnoFinito(false);

                }

            }

        }
        else {
            g.attendiTurni(g.getNumTurni()-1);
            return "<html>Il "+g.toString()+" e' in attesa</html>";
        }

        if (g.getPosizione() == n * m) {
            s+=("<br>Il " + g.toString() + " ha vinto la partita</html>");
            finito = true;
        }

        s+="</html>";
        return s;

    }



    public static void salvaFile() {

        Sistema s = new Sistema();
        s.local_n = n;
        s.local_m = m;
        s.local_numG = numGiocatori;
        s.local_manuale = manuale;
        s.local_casellePesca = casellePesca;
        s.local_casellePremio = casellePremio;
        s.local_caselleSosta = caselleSosta;

        try{

            JFileChooser fileChooser = new JFileChooser();
            fileChooser.setDialogTitle("Specify a file to save");

            int userSelection = fileChooser.showSaveDialog(new JFrame());

            if (userSelection == JFileChooser.APPROVE_OPTION) {
                File fileToSave = fileChooser.getSelectedFile();
                FileOutputStream f = new FileOutputStream(fileToSave.getAbsolutePath()+".save");
                ObjectOutputStream oos = new ObjectOutputStream(f);
                oos.writeObject(s);
                oos.close();
                f.close();

                partitaCaricata = true;
            }
        } catch (FileNotFoundException e ){

        } catch (IOException e){

        }

    }

    public static void caricaFile(){
        Sistema s;
        Object obj;
        String per = "";
        try{

            JFileChooser jfc = new JFileChooser(FileSystemView.getFileSystemView().getHomeDirectory());
            int returnValue = jfc.showOpenDialog(null);

            if (returnValue == JFileChooser.APPROVE_OPTION) {
                File selectedFile = jfc.getSelectedFile();
                per = selectedFile.getAbsolutePath();

                int index = per.lastIndexOf(".");
                String estensione = per.substring(index);

                if(!estensione.equals(".save")){
                        JOptionPane.showMessageDialog(null, "Il file selezionato non è valido");
                    }
                }

            FileInputStream fileIn = new FileInputStream(per);
            ObjectInputStream objectIn = new ObjectInputStream(fileIn);

            obj = objectIn.readObject();
            objectIn.close();
            s=(Sistema) obj;

            n=s.local_n;
            m=s.local_m;
            numGiocatori=s.local_numG;
            manuale=s.local_manuale ;
            casellePesca=s.local_casellePesca;
            casellePremio=s.local_casellePremio ;
            caselleSosta=s.local_caselleSosta ;

            partitaCaricata=true;
            partitaCreata=true;

        } catch (Exception ex){
        }
    }



    public void setManuale(boolean m){
        manuale = m;
    }

    public void setProssimo(boolean p){
        prossimoTurno = p;
    }

    public void setDadoDoppio(boolean d) { g0.setDadoDoppio(d); }

    public void setDadoSingolo(boolean d) { g0.setDadoSingolo(d); }

    public void setLancioSingolo(boolean d) { g0.setLancioSingolo(d); }

    public void setCaselleSosta(boolean d) { caselleSosta = d; }

    public void setCasellePesca(boolean d) { casellePesca = d; }

    public void setCasellePremio(boolean d) { casellePremio = d; }

    public void setUlterioriCarte(boolean d) { CasellaPesca.setRDivieto(d); }

    public void setPartitaCreata(boolean d) { partitaCreata = d; }

    public void setDimensioneTabellone(int i, int j){ n=i; m=j; }

    public void setNumGiocatori(int i){ numGiocatori=i; }

    public boolean getPartitaCaricata() { return partitaCaricata; }

    public int getN(){ return local_n; }


}